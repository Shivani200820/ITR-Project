import Navbar from "../../Components/landing/Navbar";
import HeroSection from "../../Components/landing/HeroSection";
import OverviewSection from "../../Components/landing/OverviewSection";
import HowItWorks from "../../Components/landing/HowItWorks";
import FeaturesSection from "../../Components/landing/FeaturesSection";
import StatisticsSection from "../../Components/landing/StatisticsSection";
import DepartmentsSection from "../../Components/landing/DepartmentsSection";
import ContactSection from "../../Components/landing/ContactSection";
import Footer from "../../Components/landing/Footer";
import ScrollTop from "../../Components/common/ScrollTop";

function LandingPage() {
  return (
    <>
      <Navbar />
      <HeroSection />
      <OverviewSection />
      <HowItWorks />
      <FeaturesSection />
      <StatisticsSection />
      <DepartmentsSection />
      <ContactSection />
      <Footer />
      <ScrollTop />
    </>
  );
}

export default LandingPage;